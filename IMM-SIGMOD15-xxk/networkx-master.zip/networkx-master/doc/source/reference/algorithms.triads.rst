******
Triads
******

.. automodule:: networkx.algorithms.triads
.. autosummary::
   :toctree: generated/

   triadic_census
