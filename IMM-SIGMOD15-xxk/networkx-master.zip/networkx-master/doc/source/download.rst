--------
Download
--------

Software
~~~~~~~~

Source and binary releases: http://pypi.python.org/pypi/networkx/

Github (latest development): https://github.com/networkx/networkx/


Documentation
~~~~~~~~~~~~~
As .pdf file: https://media.readthedocs.org/pdf/networkx/stable/networkx.pdf

As html in .zip file: https://readthedocs.org/projects/networkx/downloads/htmlzip/stable/
